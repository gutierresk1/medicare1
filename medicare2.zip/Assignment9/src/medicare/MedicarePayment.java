/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package medicare;

import java.text.DecimalFormat;
import java.util.Scanner;

/**
 *
 * @author Joe Waldron
 */

//here is where the comparable interface gets implemented. 
public class MedicarePayment implements Comparable{

    ////////////////////////////////////
    /// constants
    ////////////////////////////////////
    /**
     * Minimum Percent Reimbursement
     */
    public static final double MIN_PAID = 0.0;
    /**
     * Maximum Percent Reimbursement
     */
    public static final double MAX_PAID = 1.0;
    /**
     * Minimum number of outpatient services
     */
    public static final int MIN_OPS = 1;
    /**
     * Maximum number of outpatient services
     */
    public static final int MAX_OPS = 1000;

    ////////////////////////////////////
    /// formatting object
    ////////////////////////////////////

    public DecimalFormat twoDec = new DecimalFormat("0.00");   // two decimal places

    ////////////////////////////////////
    /// instance variables
    ////////////////////////////////////

    private String apc;    // ambulatory payment classification
    private int providerID;   // provider ID
    private String providerName;  // provider name
    private String providerStreetAddress;  // provider street address
    private String providerCity;  // provider city
    private String providerState;   // provider state
    private int providerZipCode;  // provider zip code
    private String hrrDescription;   // hospital referral region
    private int outpatientServices;  // number of outpatient services provided
    private double submittedCharges;   // outpatient services average estimated submitted charges
    private double totalPayments;    // average total payments


    ////////////////////////////////////
    /// constructors
    ////////////////////////////////////

    /**
     * Creates new Applicant - default
     */
    public MedicarePayment() {
        // set all instance variables to default values
        apc = "None";
        providerID = 0;
        providerName = " ";
        providerStreetAddress = " ";
        providerCity = " ";
        providerState = " ";
        providerZipCode = 0; 
        hrrDescription = " ";  
        outpatientServices = 0;
        submittedCharges = 0.0;  
        totalPayments = 0.0;  
    }



    /**
     * Creates new MedicarePayment - with all info
     * @param code String representing ambulatory payment classification
     * @param id Integer representing for provider ID
     * @param name  String representing provider name
     * @param street  String representing provider street address
     * @param city  String representing provider city
     * @param state  String representing provider state
     * @param zip Integer representing provider zip code
     * @param hrr  String representing hospital referral region description
     * @param ops  integer representing number of outpatient services provided
     * @param submit  Double representing outpatient services average estimated submitted charges
     * @param payed  Double representing average total payments
     */
    public MedicarePayment(String code, int id, String name, String street,
            String city, String state, int zip, String hrr, int ops, double submit,
            double payed) {
        apc = code;
        providerID = id;
        providerName = name;
        providerStreetAddress = street;
        providerCity = city;
        providerState = state;
        providerZipCode = zip;
        hrrDescription = hrr;
        outpatientServices = ops;
        submittedCharges = submit;
        totalPayments = payed;  
    }



    /**
     * Creates new MedicarePayment - with all info - passed in all as one comma delimited string.
     * Assumes that the String contains code, id, name, street, city, state, zip, hrr. submit, payed.
     * If not, no guarantee that applicant info will make sense (e.g. numeric name would be accepted)
     */
    public MedicarePayment(String medicarePaymentInfo) {
        ///
        try {
            /// pull out info bit by bit
            Scanner scan = new Scanner(medicarePaymentInfo);
            scan.useDelimiter(",");
            String code = scan.next();
            // System.out.println("APC1 code = " + code);
            int id = scan.nextInt();
            // System.out.println("ID1 = " + id);
            String name = scan.next();
            // System.out.println("name1 = " + name);
            String street = scan.next();
            // System.out.println("street1 = " + street);
            String city = scan.next();
            // System.out.println("city1 = " + city);
            String state = scan.next();
            // System.out.println("state1 = " + state);
            int zip = scan.nextInt();
            // System.out.println("zip1 = " + zip);
            String hrr = scan.next();
            // System.out.println("hrr1 = " + hrr);
            int ops = scan.nextInt();
            // System.out.println("ops1 = " + ops);
            // String opsString = scan.next();
            // System.out.println("opsString1 = " + opsString);
            // int ops = Integer.getInteger(opsString);
            // System.out.println("ops1 = " + ops);
            double submit = scan.nextDouble();
            // System.out.println("submit1 = " + submit);
            double payed = scan.nextDouble();
            // System.out.println("payed1 = " + payed);
            // fill in instance variables 
            apc = code;
            // System.out.println("APC2 code = " + apc);
            providerID = id;
            // System.out.println("ID2 = " + providerID);
            providerName = name;
            providerStreetAddress = street;
            providerCity = city;
            providerState = state;
            providerZipCode = zip;
            hrrDescription = hrr;
            outpatientServices = ops;
            submittedCharges = submit;
            totalPayments = payed;  
        }
        catch (Exception ex) {
            // any exception would be bad news
            // anything after that point would get a default value
        }
    }

   

    ////////////////////////////////////
    /// inspectors / accessors / getters
    ////////////////////////////////////

    /**
     * report the ambulatory procedure classification code
     * @return the string representing the apc
     */
    public String getApc() {
        return apc;
    }

    /**
     * report the provider id code
     * @return the integer representing the provider id code
     */
    public int getProviderID() {
        return providerID;
    }
    
     /**
     * report the provider name
     * @return the string representing the provider's name
     */
    public String getProviderName() {
        return providerName;
    }
    
    /**
     * report the provider street address
     * @return the string representing the provider's street address
     */
    public String getProviderStreetAddress() {
        return providerStreetAddress;
    }
    
    /**
     * report the provider city
     * @return the string representing the provider's city
     */
    public String getProviderCity() {
        return providerCity;
    }
    
    /**
     * report the provider state
     * @return the string representing the provider's state
     */
    public String getProviderState() {
        return providerState;
    }
    
    /**
     * report the provider zip code
     * @return the integer representing the provider's zip code
     */
    public int getProviderZipCode() {
        return providerZipCode;
    }
    
    /**
     * report the hospital referral region (hrr) description
     * @return the string representing the provider's hospital referral region (hrr)
     */
    public String getHrrDescription() {
        return hrrDescription;
    }
    
    /**
     * report the number of outpatient services provided
     * @return the integer representing the number of outpatient services provided
     */
    public double getOutpatientServices() {
        return outpatientServices;
    }
    
    /**
     * report the outpatient services average estimated submitted charges
     * @return the string representing the average submitted charges
     */
    public double getSubmittedCharges() {
        return submittedCharges;
    }
    
    /**
     * report the average total payments
     * @return the double representing the average total payments
     */
    public double getTotalPayments() {
        return totalPayments;
    }
    

    ////////////////////////////////////
    /// pseudo inspectors
    ////////////////////////////////////

    /**
     * report the provider's average percent reimbursement
     * @return a double representing the average percent payment of submitted charges
     */
    public double getAveragePercentReimbursement() {
        return totalPayments / submittedCharges;
    }

  
    ////////////////////////////////////
    /// mutators / setters
    ////////////////////////////////////

    /**
     * Change the ambulatory procedure classification (APC) code - cannot validate
     * @param code a string representing an ambulatory procedure classification code
     */
    public void setApc(String code) {
        apc = code ;
    }
   
    /**
     * Change the provider ID - cannot validate
     * @param id an integer representing the provider ID
     */
    public void setProviderID(int id) {
        providerID = id ;
    }
    
    /**
     * Change the provider name - cannot validate
     * @param name a string representing the provider name
     */
    public void setProviderName(String name) {
        providerName = name ;
    }
    
    /**
     * Change the provider street address - cannot validate
     * @param street a string representing the provider street
     */
    public void setProviderStreetAddress(String street) {
        providerStreetAddress = street ;
    }
    
    /**
     * Change the provider city - cannot validate
     * @param city a string representing the provider city
     */
    public void setProviderCity(String city) {
        providerCity = city ;
    }
   
    /**
     * Change the provider state - cannot validate
     * @param state a string representing the provider state
     */
    public void setProviderState(String state) {
        providerState = state ;
    }
    
    /**
     * Change the provider zip code - cannot validate
     * @param zip an integer representing the zip code
     */
    public void setProviderZipCode(int zip) {
        providerZipCode = zip ;
    }
    
    /**
     * Change the hospital referral region (hrr) description
     * @param hrr  represents the hospital referral region
     */
    public void setHrrDescription(String hrr) {
        hrrDescription = hrr ;
    }
    
    /**
     * Change the outpatient services average estimated submitted charges - cannot validate
     * @param submit a double representing the average submitted charges
     */
    public void setSubmittedCharges(double submit) {
        submittedCharges = submit;
    }
    
    /**
     * Change the number of outpatient services - cannot validate
     * @param ops an integer representing the number of outpatient services
     */
    public void setOutpatientServices(int ops) {
        outpatientServices = ops ;
    }
    
    /**
     * Change the average total payments - cannot validate
     * @param payed a double representing the average total payments
     */
    public void setTotalPayments(double payed) {
        totalPayments = payed ;
    }
    
    ////////////////////////////////////
    /// controlled mutators
    ////////////////////////////////////




    ////////////////////////////////////
    /// override versions of Object methods
    ////////////////////////////////////

    /**
     * create a string representation of a MedicarePayment
     * @return
     */
    @Override
    public String toString () {
        String res = "";
        res += "APC: " + getApc() + " ";
        res += "Provider ID: " + getProviderID() + " ";
        res += "Provider Name: " + getProviderName() + " ";
        res += "Provider Street Address: " + getProviderStreetAddress() + " ";
        res += "Provider City: " + getProviderCity() + " ";
        res += "Provider State: " + getProviderState() + " ";
        res += "Provider Zip Code: " + getProviderZipCode() + " ";
        res += "HRR: " + getHrrDescription() + " ";
        res += "Outpatient Services: " + getOutpatientServices() + " ";
        res += "Average Submitted Charge: " + twoDec.format(getSubmittedCharges()) + " ";
        res += "Average Total Payment: " + twoDec.format(getTotalPayments());
        return res;
    }

    /**
     * report whether passed object is completely equal in contents to invoking object
     * @return 
     */
    @Override
    public int hashCode () {
        int hash = 5;
        hash = 37 * hash + (this.twoDec != null ? this.twoDec.hashCode() : 0);
        hash = 37 * hash + (this.apc != null ? this.apc.hashCode() : 0);
        hash = 37 * hash + this.providerID;
        hash = 37 * hash + (this.providerName != null ? this.providerName.hashCode() : 0);
        hash = 37 * hash + (this.providerStreetAddress != null ? this.providerStreetAddress.hashCode() : 0);
        hash = 37 * hash + (this.providerCity != null ? this.providerCity.hashCode() : 0);
        hash = 37 * hash + (this.providerState != null ? this.providerState.hashCode() : 0);
        hash = 37 * hash + this.providerZipCode;
        hash = 37 * hash + (this.hrrDescription != null ? this.hrrDescription.hashCode() : 0);
        hash = 37 * hash + (int) (Double.doubleToLongBits(this.submittedCharges) ^ (Double.doubleToLongBits(this.submittedCharges) >>> 32));
        hash = 37 * hash + (int) (Double.doubleToLongBits(this.totalPayments) ^ (Double.doubleToLongBits(this.totalPayments) >>> 32));
        return hash;
    }

    @Override
    public boolean equals(Object toCompare) {
        if (toCompare instanceof MedicarePayment) {
            MedicarePayment other = (MedicarePayment) toCompare;
            if ((this.getApc().equals(other.getApc()))
                    && (this.getProviderID() == (other.getProviderID()))
                    && (this.getProviderName().equals(other.getProviderName()))
                    && (this.getProviderStreetAddress().equals(other.getProviderStreetAddress()))
                    && (this.getProviderCity().equals(other.getProviderCity()))
                    && (this.getProviderState().equals(other.getProviderState()))
                    && (this.getProviderZipCode() == other.getProviderZipCode())
                    && (this.getHrrDescription().equals(other.getHrrDescription()))
                    && (this.getOutpatientServices() == other.getOutpatientServices())
                    && (this.getSubmittedCharges() == other.getSubmittedCharges())
                    && (this.getTotalPayments() == other.getTotalPayments())) {
                return true;
            }
            else {
                // not all equal
                return false;
            }
        }
        else {
            // if not same type cannot be equal
            return false;
        }
    }
    //////////////////////////////////
    /// for Comparable
    //////////////////////////////////
    /** Compares two MedicarePayment Records - needed for sorting.
     * Required since implements Comparable interface. 
     * Returns negative if object comparing to is less, zero if object comparing to is equal, 
     * positive if object comparing to is greater. 
     * Compare based on code for State and APC code .
     * @param obj
     */
    
    ///nothing got changed in this class except the compare to. we override from the interface version
    @Override
    public int compareTo (Object obj) {
        MedicarePayment comparedPay  = (MedicarePayment)obj;
        //we cast the medicarepayment object class so the object will be more defined. 
            if(this.providerState.equals(comparedPay.providerState)){
                //firsts checks the two Medicarepayment state string objects.
                //then compares the apc code
                if(this.apc.equals(comparedPay.apc)){
                    //return 0 to mean equal. 
                    return 0; 
                }else{
                    //the apc do not equal and the sorting will start. 
                    return this.apc.compareTo(comparedPay.apc);
                }
            }else{
                //if both states are not equal, then not equal. 
                return this.providerState.compareTo(comparedPay.providerState);
            }
    }
    

}
