/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package medicare;

import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.ResourceBundle;
import java.util.Set;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;

/**
 * FXML Controller class
 *
 * @author khanhhang
 * date 4/18/2020
 * e-mail: hoangh3@student.lasalle.edu
 * Purpose: To use the choicebox drop down select with populates state Abbreviations and display 
 * data resulting from the selection: state avg and apc.
 */
public class FXMLDocumentController implements Initializable {

    @FXML
    private Label stateName;
    @FXML
    private TextArea txtAreaAvg;
    @FXML
    private Label avgPayment;
    @FXML
    private Button btnQuit;
    @FXML
    private ComboBox<String> cbStates;
    //decided to put the string created in the statemedicareledger class into an arraylist
    StateMedicareLedger ledger; 
    //the object for the class
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
       
        ledger = new StateMedicareLedger(); 
        //instantiate it
        ArrayList<String> stateNames = new ArrayList<>(); 
        String [] stateArray = ledger.getStates().split(",");
        //using split to create an array of state names, cutting of each state with ','. 
        //add all of the array onto the arraylist
        stateNames.addAll(Arrays.asList(stateArray));
        
        //populate the combobox
        cbStates.getItems().addAll(stateNames);
    }    

    @FXML
    private void BtnActionQuit(ActionEvent event) {
        //exit systtem
        System.exit(0);
    }

    @FXML
    private void cbBoxActionMade(ActionEvent event) {
        //get String state selected by user.
        String selectedValue = cbStates.getValue(); 
        
        stateName.setText(selectedValue);
        //used the ledger methods to populate the labels
        avgPayment.setText(ledger.getStateAvg(selectedValue));
        txtAreaAvg.setText(ledger.getStateApcAvg(selectedValue));
    }
    
}
