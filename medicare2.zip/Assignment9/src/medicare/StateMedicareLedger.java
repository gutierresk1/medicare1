 /*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package medicare;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.HashSet;
import java.util.Set;
import javax.swing.JOptionPane;

/**
 *
 * @author Joe Waldron HP
 */
public class StateMedicareLedger {
    /** list of MedicarePayment objects.  The list has a sort order as defined 
     * in the MedicarePayment class.  For the purposes of this implementation, 
     * the list of MedicarePayment objects is sorted by state, and within state
     * by APC code
     */
    private ArrayList<MedicarePayment> allPayments = new ArrayList<MedicarePayment>(); 
    
    /** the default constructor
     * reads a file containing Medicare payments, and establishes an Array of
     * MedicarePayment objects, with a primary sort on state, and a secondary 
     * sort on APC
     */
    public StateMedicareLedger() {
        //Instead of reader the file in the controller, we read it now through this class 
        try {//We use the BufferedReader to ge the filepath of the MedicareData.txt
            
            ArrayList<String> stringLine;
            BufferedReader br = new BufferedReader(new FileReader("src/medicare/MedicareData.txt"));	
            String line = "";
            //the stringLine is an ArrayList of type String.      
            stringLine = new ArrayList<>();

            while((line = br.readLine())!=null){
                //we use a while loop to read a line from the MedicareData.txt file
                stringLine.add(line);
                //each string in the arraylist corresponds to one  line in the txt file
            }
            
            
            for(int i=0; i<stringLine.size(); i++){
                String medicarePaymentInfo = stringLine.get(i);
                //iterate through the string arraylist, and add it to the String made above. 
                MedicarePayment newPmt = new MedicarePayment(medicarePaymentInfo);
                //we use the Constructor that uses one parameter to make a MedicarePayment object
                allPayments.add(newPmt);
                //add it to the MedicarePayment ArrayList 
            }   
            System.out.println(allPayments.size());
            //checks size of arraylist
            
            Collections.sort(allPayments);
            //This is where the arraylist of MedicarePayment objects gets sorted and compareTo gets used. 
            //Primary is stateName, then APC code. 
        }catch (IOException e) {
			e.printStackTrace();
		}
        
    }
    
    /** creates a list of distinct state abbreviations, in ascending alpha order
     * @return a string containing a list of state abbreviations separated by 
     * commas
     */
    public String getStates() {
        String stateList = "", nextState, prevState = "";
        int cnt = 0;
         // loop through allStates.  This assumes that allStates is already in sort order by state
        for (MedicarePayment sp : allPayments) {
            nextState = sp.getProviderState();
                    // compare next state to previous; only add to list to be returned if different
                    if(prevState.compareTo(nextState) != 0 ){
                         stateList = stateList+nextState + ",";
                         cnt++;
                         prevState = nextState;
                    }
        }
        // send evidence of number of distinct state names to output window
        System.out.println(cnt + " distinct state names were found");
        return stateList;
    }
    
    /** creates a string representing the average percentage paid for all claims
     * made by the state
     * the average is determined as follows:
     *    for each payment associated with the state, multiply the average 
     *         submitted charge by the number of such outpatient services 
     *         performed
     *    sum all these products (refer to below as B)
     *    for each payment associated with the state, multiply the average 
     *        total payments by the number of such outpatient services performed
     *    sum all the products (refer to below as A)
     *    divide A by B express as a percent with 2 decimal places
     * @param state is a string containing a state abbreviation.  This is the 
     * state for which the average will be returned
     * @return a string representing the average for the state expressed as a 
     * 2 decimal place percentage
     */
    public String getStateAvg(String state) {
        //global variables to keep track of the sum of all products
        double sumA = 0; 
        double sumB = 0; 
        //for each loop iterating thriugh the sorted arraylist. 
        for(MedicarePayment currentPayment: allPayments){
            //condition that checks if the current iteration of the object's state is equal 
            //to the User's selected state. 
            if(currentPayment.getProviderState().equals(state)){
                //var that multiplies the average submitted charge by the number of such outpatient services performed
               double arithmetic =  currentPayment.getSubmittedCharges() * currentPayment.getOutpatientServices();
               sumB += arithmetic; 
               //add it to the sum of products B
               
               //same logic with sum of products A. 
               double arithmetic2 = currentPayment.getTotalPayments() * currentPayment.getOutpatientServices();
               sumA += arithmetic2; 
            }
        }
        //convert the division to percent form 
        double finalArth= (sumA/ sumB)*100; 
        DecimalFormat df = new DecimalFormat("#.##");
        double newFormat = Double.parseDouble(df.format(finalArth));
        //returns percentage. 
        return newFormat+"%"; 
    }
    
    /** creates a string containing a series of average percentages each on its 
     *  own line. Each line represents the average percentage paid for all 
     *  claims made by the state and for that apc code
     *  the average for each line is calculated as follows:
     *    for each payment associated with the combination of state and apc code
     *             multiply the average submitted charge by the number of such 
     *             outpatient services performed
     *    sum all these products (refer to below as B)
     *    for each payment associated with the combination of state and apc code
     *             multiply the average total payments by the number of such 
     *             outpatient services performed
     *    sum all the products (refer to below as A)
     *    divide A by B express as a percent with 2 decimal places
     * @param state is a string containing a state abbreviation.  This is the 
     * state for which the average will be returned
     * @return a string containing the average for the state and apc code 
     * combination, expressed as a 2 decimal place percentage, each on its own 
     * line
     */
    public String getStateApcAvg(String state) {
        //global variables that keeps track of previous APC and the next APC(current APC)
        String previousApc = ""; 
        String nextApc;
        
        //the three vars will record that last arithmetic  iteration of the for each loop. 
        double lastCharge = 0.0; 
        double lastOutPat = 0.0; 
        double lastPayment = 0.0; 
        
        //global variables to keep track of product of sums. 
        double sumB = 0.0; 
        double sumA = 0.0; 
        int cnt = 0; 
        //counter to determine if there is more than one instance of the APC code
        //Main String that adds the list of Apc and state avg.  
        String stateAndAPCList = ""; 
        for(MedicarePayment current : allPayments){
         if(current.getProviderState().equals(state)){
             //gets current APC
            nextApc = current.getApc();
            //condition that checks if the current payment object is the first iteration. 
            if(!previousApc.equals("")){ 
                //if not, checks to see if the current APC has more than one instance
                    if (nextApc.equals(previousApc)){ 
                        //if so, do the state state avg calculations, while incrementing the counter.
                            double arithmetic =  current.getSubmittedCharges() * current.getOutpatientServices();
                            sumB += arithmetic; 

                            double arithmetic2 = current.getTotalPayments() * current.getOutpatientServices();
                            sumA += arithmetic2; 
                            //the counter to say there is more than one instance of the APC code. 
                            cnt++; 
                        }else{
                            //If this is a new APC code, we go here. 
                            if(cnt <= 0){
                                //if this is the first instance of the APC code, we  
                                //calculate state average and increment  the counter. 
                                double arithmetic =  current.getSubmittedCharges() * current.getOutpatientServices();
                                sumB += arithmetic; 

                                double arithmetic2 = current.getTotalPayments() * current.getOutpatientServices();
                                sumA += arithmetic2;
                                cnt++; 
                            }else{
                                //We calculate the previous instance of the stae chosen with that particular APC code. 
                                //if not the first instance, we convert the avg into percent form. 
                                double finalArth= (sumA/sumB)*100; 
                                DecimalFormat df = new DecimalFormat("#.##");
                                double newFormat = Double.parseDouble(df.format(finalArth));
                                
                                //use string split to remove words and keep the APC code. 
                                String [] splitString  = previousApc.split("-");
                                String codeOnly = splitString [0];
                                //We save the avg of the state with this particular code into the 
                                //String list
                                stateAndAPCList = stateAndAPCList + codeOnly +"  "+ newFormat + "% "+"\n";
                                
                                //We reset values, as they only are needed for each new instanc eof the APC code. 
                               
                                sumB = 0.0; 
                                sumA = 0.0; 
                                cnt = 0; 
                                
                                //For the current APC code. We go here and add it to our iteration. 
                                 double arithmetic =  current.getSubmittedCharges() * current.getOutpatientServices();
                                sumB += arithmetic; 

                                double arithmetic2 = current.getTotalPayments() * current.getOutpatientServices();
                                sumA += arithmetic2; 
                                cnt++; 
                            }
                        }
                    }else{
                //this is for the very first payment object in the list. 
                        double arithmetic =  current.getSubmittedCharges() * current.getOutpatientServices();
                        sumB += arithmetic; 

                        double arithmetic2 = current.getTotalPayments() * current.getOutpatientServices();
                        sumA += arithmetic2;          
            }
                previousApc = nextApc; 
                //we change values so that the current object here will be used as the next previous object. 
                //we use these outside the loop, so for the final iteration, it's values get stored here. 
                lastCharge = current.getSubmittedCharges();
                lastOutPat = current.getOutpatientServices();
                lastPayment = current.getTotalPayments();
            }
        }
        
        //Last calculation for the final Object in the payment class.         
        double finalArth= (sumA/sumB)*100; 
        DecimalFormat df = new DecimalFormat("#.##");
        double newFormat = Double.parseDouble(df.format(finalArth));

        String [] splitString  = previousApc.split("-");
        String codeOnly = splitString [0];
        stateAndAPCList = stateAndAPCList + codeOnly +"  "+ newFormat + "% "+"\n";
        
        //we return. 
        return stateAndAPCList; 
    }

}