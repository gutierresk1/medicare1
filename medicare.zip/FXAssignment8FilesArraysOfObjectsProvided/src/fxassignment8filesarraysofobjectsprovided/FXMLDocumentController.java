/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fxassignment8filesarraysofobjectsprovided;

import static fxassignment8filesarraysofobjectsprovided.MedicarePayment.MAX_PAID;
import static fxassignment8filesarraysofobjectsprovided.MedicarePayment.MIN_PAID;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.ResourceBundle;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

/**
 * FXML Controller class
 *
 * @author khanhhang
 * Purpose: To Read in a file that has multiple uses, such as looking at the number of percentages. 
 * Also, to calculate the Outpatient services and Calculate the minimum target. 
 */
public class FXMLDocumentController implements Initializable {

    @FXML
    private Label label1;
    @FXML
    private Label label;
    @FXML
    private Label label2;
    @FXML
    private Label label21;
    @FXML
    private TextField servNumber;
    @FXML
    private Label label3;
    @FXML
    private TextField txtReimbursed;
    @FXML
    private Label label31;
    @FXML
    private TextField txtTarget;
    @FXML
    private Button calcMinButton;
    @FXML
    private Button btnReimbursed;
    @FXML
    private Button btnOutpat;
    @FXML
    private Button btnQuit;
    ArrayList<MedicarePayment> listPmt; 
    ArrayList<String> stringLine;
    ArrayList<Double> targetValues; 
    
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        targetValues = new ArrayList<>();
        File file = new File("src/fxassignment8filesarraysofobjectsprovided/MedicareData.txt");
        if(file.exists()){
            //To start the file
            start();
        }else{
            Alert  alert = new Alert(Alert.AlertType.INFORMATION);
                   alert.setTitle("Information Dialog");
                   alert.setHeaderText(null);
                   alert.setContentText(file.getName()+" file not found. Quit and put file in project folder");
                   alert.showAndWait();
        }
    }    
    
    public void start(){
     	try {//We use the BufferedReader to ge the filepath of the MedicareData.txt
            BufferedReader br = new BufferedReader(new FileReader("src/fxassignment8filesarraysofobjectsprovided/MedicareData.txt"));	
            String line = "";
            //the stringLine is an ArrayList of type String. 
            stringLine = new ArrayList<>();
            
            while((line = br.readLine())!=null){
                //we use a while loop to read a line from the MedicareData.txt file
                stringLine.add(line);
                //each string in the arraylist corresponds to one  line in the txt file
            }           
            //instantiate the arraylist
            listPmt = new ArrayList<>();
            
            
            for(int i=0; i<stringLine.size(); i++){
                String medicarePaymentInfo = stringLine.get(i);
                //iterate through the string arraylist, and add it to the String made above. 
                MedicarePayment newPmt = new MedicarePayment(medicarePaymentInfo);
                //we use the Constructor that uses one parameter to make a MedicarePayment object
                listPmt.add(newPmt);
                //add it to the MedicarePayment ArrayList 
            }   
            System.out.println(listPmt.size());
            //checks size of arraylist
        }catch (IOException e) {
			e.printStackTrace();
		}
    }


    @FXML
    private void handleButtonReimbursed(ActionEvent event) {
        String userReim = txtReimbursed.getText();
        Double reimVal = Double.parseDouble(userReim);
        //Using a conditional to validate the user Reimbursement decimal. 
        if(reimVal < 0.0 || reimVal > 1.0){
            //Alert to make sure that the Payment Reimbursement Percent needs to be between 0.0 and 1.0
            Alert  alert = new Alert(Alert.AlertType.INFORMATION);
                   alert.setTitle("Information Dialog");
                   alert.setHeaderText(null);
                   alert.setContentText("Payment Reimbursement Percent needs to be between 0.0 and 1.0");
                   alert.showAndWait();
        }else{
            
            int counter = 0; 
            //foreach loop that iterates through the listPmt ArrayList.
            for(MedicarePayment currentPayment: listPmt){
                //we retrieve the current object's Average Percent Reimbursement
                double currentReim = currentPayment.getAveragePercentReimbursement();
                //using DecimalFormat to format the decimal
                DecimalFormat df = new DecimalFormat("#.##");
                double newFormat = Double.parseDouble(df.format(currentReim));
                //System.out.println(newFormat);
                if(newFormat > reimVal){
                    //if its iin the threshold, the counter gets incremented. 
                    counter++;
                }
            }
            String percentage = formatPercent(reimVal, 0); 
            //using method to create a String by formating the double parameter, to how many places
            //depending on the second parameter. 
            Alert  alert = new Alert(Alert.AlertType.INFORMATION);
                   alert.setTitle("Information Dialog");
                   alert.setHeaderText(null);
                   alert.setContentText(counter+" payments meet the threshold of "+percentage+" of submitted payment reimbursed.");
                   alert.showAndWait();
        }
    }

    @FXML
    private void handleButonOutpat(ActionEvent event) {
        //get text
        String userServ = servNumber.getText();
        int servVal = Integer.parseInt(userServ);
        //conditional to check if text is between 1 and 1000
        if(servVal < 1|| servVal > 1000){
              Alert  alert = new Alert(Alert.AlertType.INFORMATION);
                   alert.setTitle("Information Dialog");
                   alert.setHeaderText(null);
                   alert.setContentText("Outpatient Services Number needs to be between 1 and 1000");
                   alert.showAndWait();
        }else{
            int counter = 0; 
            double newFormat = servVal;
            for(MedicarePayment currentPmt: listPmt){
                //itertate through the listPmt ArrayList
                double currentOut = currentPmt.getOutpatientServices();
                //current OutPatient Services
                if(currentOut>=newFormat){
                    //meets threshold, increment counter
                    counter++; 
                }
            }
            Alert  alert = new Alert(Alert.AlertType.INFORMATION);
                   alert.setTitle("Information Dialog");
                   alert.setHeaderText(null);
                   alert.setContentText(counter+" payments meet the threshold of "+newFormat+" of patients for outpatient services.");
                   alert.showAndWait();
        }
    }

    @FXML
    private void handleButtonBoth(ActionEvent event) {
        String userReim = txtReimbursed.getText();
        Double reimVal = Double.parseDouble(userReim);
        
        String userServ = servNumber.getText();
        int servVal = Integer.parseInt(userServ);
        
        //The conditional adds the previous button's conditionals
        if((reimVal < 0.0 || reimVal > 1.0)&&(servVal < 1|| servVal > 1000)){
            Alert  alert = new Alert(Alert.AlertType.INFORMATION);
                   alert.setTitle("Information Dialog");
                   alert.setHeaderText(null);
                   alert.setContentText("Payment Reimbursement Percent needs to be between 0.0 and 1.0. Outpatient Services Number needs to be between 1 and 1000");
                   alert.showAndWait();
        }else{
            int counter = 0; 
            double newServFormat = servVal;
            
            for(MedicarePayment currPmt : listPmt){
                double currentReim = currPmt.getAveragePercentReimbursement();
                DecimalFormat df = new DecimalFormat("#.##");
                double newFormat = Double.parseDouble(df.format(currentReim));
                
                double currentOut = currPmt.getOutpatientServices();
                
                if((newFormat > reimVal)&&(currentOut>=newServFormat)){
                    //check the threshold of both the reimbursement and Out Patient Services Number
                    counter++;
                }
            }
            Alert  alert = new Alert(Alert.AlertType.INFORMATION);
                   alert.setTitle("Information Dialog");
                   alert.setHeaderText(null);
                   alert.setContentText(counter+" payments meet all of the thresholds");
                   
                   alert.showAndWait();
        }
    }
        
    @FXML
    private void handleButtonCalc(ActionEvent event) {
        String userTarget = txtTarget.getText(); 
        double targetValue = Double.parseDouble(userTarget);
            double percentageRecords = targetValue * listPmt.size(); 
            int counterCriteria = 0;
            double cnt = 0; 

            while(cnt <=1) { 
                for(MedicarePayment currPmt:listPmt){
                    double currentCharges = currPmt.getSubmittedCharges();
                    double currentTotalPayments = currPmt.getTotalPayments();
                    double reimArithmetic = currentCharges/currentTotalPayments;
                    
                        if(cnt<=reimArithmetic){   
                            counterCriteria++;   
                        }
                }
                        if(counterCriteria>percentageRecords){
                            cnt+=0.0001; 
                            counterCriteria = 0; 
                        }else{
                            break; 
                        }
                    } 
                    String percentage = formatPercent(cnt,0);
                    String targetPercent = formatPercent(targetValue, 0);
                    Alert  alert = new Alert(Alert.AlertType.INFORMATION);
                   alert.setTitle("Information Dialog");
                   alert.setHeaderText(null);
                   alert.setContentText("Target Reimbursement of "+percentage+" will return "+ ""
                   +" records, representing a count of no more than "+targetPercent+" of total records");
                   alert.showAndWait();    
               
    }

    @FXML
    private void handleButtonQuit(ActionEvent event) {
        System.exit(0);
    }
   
    public static String formatPercent(double done, int digits) {
        DecimalFormat percentFormat = new DecimalFormat("0.0%");
        percentFormat.setDecimalSeparatorAlwaysShown(false);
        percentFormat.setMinimumFractionDigits(digits);
        percentFormat.setMaximumFractionDigits(digits);
        return percentFormat.format(done);
  }
    public double findNearestDoubleInList(ArrayList<Double> arrayList, double x){
            double answer = arrayList.get(0);
            double current = Double.MAX_VALUE;
            for (Double value : arrayList) {
                if (Math.abs(value - x) < current) {
                    answer = value;
                    current = Math.abs(value - x);
                }
            }
        return answer; 
    }
}